﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class Trigger : MonoBehaviour {
	
	public GameObject cube;
	public GameObject checkPoint;

	void OnCollisionEnter(Collision col)
	{
		Destroy (col.gameObject);
	}
}
