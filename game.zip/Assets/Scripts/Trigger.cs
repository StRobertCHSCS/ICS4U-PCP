﻿using UnityEngine;
using System.Collections;

public class Trigger : MonoBehaviour {
	public GameObject cube;

	void OnCollisionEnter(Collision col)
	{
		Destroy(col.gameObject);
	}
}
