﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class Move : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		transform.position += new Vector3(Input.GetAxis("Horizontal"), 0, 0);
	}

	void OnCollisionEnter() 
	{
		Destroy(gameObject);
		SceneManager.LoadScene ("LostMenu");
	}
}
