﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class Move : MonoBehaviour {
	
	public static float time;

	// Update is called once per frame
	void Update () 
	{
		transform.position += new Vector3(Input.GetAxis("Horizontal"), 0, 0);
	}

	void OnCollisionEnter() 
	{
		SceneManager.LoadScene ("LostMenu");
		Destroy(gameObject);
	}
}
