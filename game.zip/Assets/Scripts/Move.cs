﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class Move : MonoBehaviour {

	// Update is called once per frame
	void Update () {
		transform.position += new Vector3(Input.GetAxis("Horizontal"), 0, 0);
	}

	void OnCollisionEnter(Collision col) {
		Destroy (gameObject);
		Time.timeScale = 1.0f;
		SceneManager.LoadScene ("LostMenu");
	}
}
