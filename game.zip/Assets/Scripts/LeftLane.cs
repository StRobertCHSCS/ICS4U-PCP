﻿using UnityEngine;
using System.Collections;

public class LeftLane : MonoBehaviour {
	public float minTime = 0.1f;
	public float maxTime = 1;
	public GameObject cube;

	private float time;
	private float delay;
	private float startTime;

	void setRandomTime()
	{
		delay = Random.Range (minTime, maxTime);
	}

	void SpawnL () {
		time = 0.005f;
		Instantiate (cube,new Vector3(-3, 12, 0), Quaternion.identity);
	}

	// Use this for initialization
	void Start () {
		startTime += Time.deltaTime;

		if (startTime >= 0.5f) {
			InvokeRepeating ("SpawnL", delay, delay);
		}
	}

	// Update is called once per frame
	void FixedUpdate()
	{
		// Counts up
		time += Time.deltaTime;

		//Check if its the right time to spawn the object
		if (time >= delay) {
			SpawnL ();
			setRandomTime ();
		}
	}
}
