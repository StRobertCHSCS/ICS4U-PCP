﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class highScore : MonoBehaviour {

	Text highScoreText;

	public int highscore;

	// Use this for initialization
	void Start () {
		highScoreText = GetComponent<Text>();

		if (PlayerPrefs.HasKey ("High Score")) {
			highscore = PlayerPrefs.GetInt("High Score");
		} else {
			PlayerPrefs.SetInt ("High Score", 0);
		}
		PlayerPrefs.Save ();
	}
	
	// Update is called once per frame
	void Update () {
		highScoreText.text = highscore.ToString();
	}
}
