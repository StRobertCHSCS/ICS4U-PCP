﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Score : MonoBehaviour {

	Text scoreText;

	public int score;
	public int highscore;
	public static float time;

	void Start() {			
		scoreText = GetComponent<Text> ();
		score = 0;
	}

	// Update is called once per frame
	void Update () {
		time += Time.deltaTime;
		if (time > 0.75f) {
			score += 1;
			time = 0.0f;
		}
		if (score > highscore) {
			highscore = score;
			PlayerPrefs.SetInt("High Score", highscore);
			PlayerPrefs.Save ();
		}
		scoreText.text = "" + score;
	}
}
