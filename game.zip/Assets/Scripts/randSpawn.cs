﻿using UnityEngine;
using System.Collections;

public class randSpawn : MonoBehaviour {

	public float gameTime;
	public ArrayList lanes;
	public Transform obstaclePrefab;
	public int yVal;

	public static float lanePos;

	void Start () {
		lanes = new ArrayList{-3, 0, 3};
		gameTime = 0.0f;
	}
	
	// Update is called once per frame
	void Update () {
		gameTime += Time.deltaTime;
		if (gameTime > 0.65f) {

			lanePos = (int)lanes[Random.Range(0,3)];
			Instantiate (obstaclePrefab, new Vector3 (lanePos, 12, 0), Quaternion.identity);

			gameTime = 0.0f;
		}
	}
}