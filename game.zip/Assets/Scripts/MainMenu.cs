﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections;

public class MainMenu : MonoBehaviour {

	public void ChangeScene(string sceneName)
	{
		SceneManager.LoadScene (sceneName);
	}
}
