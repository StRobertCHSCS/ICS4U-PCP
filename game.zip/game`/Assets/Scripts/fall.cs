﻿using UnityEngine;
using System.Collections;

public class fall : MonoBehaviour {

	public static float fallSpeed = 250.0f;


	void Update() {

		transform.Translate(Vector3.down * fallSpeed * Time.deltaTime, Space.World);


	}
}