﻿using UnityEngine;
using System.Collections;

public class CPointCollider : MonoBehaviour {

	public static int playerScore;

	// Use this for initialization
	void Start () {
		playerScore = Score.score;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter(Collider other) {
		if (other.name == "Sphere") {
			if (fall.fallSpeed < 700.0f) {
				fall.fallSpeed += 50.0f;
			}
			Score.score += 10;
		} else if (other.tag == "ClearLag") {
			Destroy (gameObject);
		}
	}
}
