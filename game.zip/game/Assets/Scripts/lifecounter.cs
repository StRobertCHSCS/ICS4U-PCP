﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class lifecounter : MonoBehaviour {
	Text lifeText;
	// Use this for initialization
	void Start () {

		lifeText = GetComponent<Text> ();

	}

	// Update is called once per frame
	void Update () {
		lifeText.text = Move.numlife.ToString();
	}
}
