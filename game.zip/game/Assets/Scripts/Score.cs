﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Score : MonoBehaviour {

	Text scoreText;

	public static int score;
	public int highscore;
	public float time;

	void Start() {

		highscore = PlayerPrefs.GetInt ("HighScore", 0);
		scoreText = GetComponent<Text> ();
		score = 0;
		time = 0.0f;
	}

	// Update is called once per frame
	void Update () {

		//Time scale being altered in /CPointCollider.cs allows these values to match that of others which also use delta time.
		time += Time.deltaTime;

		// Increase score by 1 every 0.75 seconds.
		if (time > 0.75f) {
			score += 1;
			time = 0.0f;
		}

		// Update score's text.
		scoreText.text = score.ToString();
	}

	void OnDisable() {
		
		// Update highscore if current score is greater.
		if (score > highscore) {
			PlayerPrefs.SetInt("HighScore", score);
			PlayerPrefs.Save ();
		}
	}
}
