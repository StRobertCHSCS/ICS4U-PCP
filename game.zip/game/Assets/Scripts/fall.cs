﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class fall : MonoBehaviour {


	public static float fallSpeed = 600.0f;



	void Update() {

		transform.Translate(Vector3.down * fallSpeed * Time.deltaTime, Space.World);








	}
}