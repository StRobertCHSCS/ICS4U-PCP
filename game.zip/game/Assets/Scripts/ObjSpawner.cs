﻿using UnityEngine;
using System.Collections;

public class ObjSpawner : MonoBehaviour {

	public float gameTime;
	public int oldX;
	public ArrayList lanes;
	public float lanePos;
	public float cpTime;
	public float lifeTime;
	public int oldlifeX;

	void Start () {
		
		lanes = new ArrayList{-350, 0, 350};
		gameTime = 0.0f;
		cpTime = 0.0f;
		lifeTime = 0.0f;
	}
	
	// Update is called once per frame
	void Update () {
		
		gameTime += Time.deltaTime;
		cpTime += Time.deltaTime;
		lifeTime += Time.deltaTime;

		// Spawn a cube when 0.65 theoretical seconds have passed, and if its x-val has been used, pick another random one in attempt to reduce x-repetition.
		if (gameTime > 1.20f) {
			
			lanePos = (int)lanes[Random.Range(0,3)];

			if (lanePos != oldX) {
				Instantiate (Resources.Load("Cube"), new Vector3 (lanePos, 1200, 0), Quaternion.identity);
				oldX = (int)lanePos;
			} else {
				lanePos = (int)lanes[Random.Range(0,3)];
				Instantiate (Resources.Load("Cube"), new Vector3 (lanePos, 1200, 0), Quaternion.identity);
				oldX = (int)lanePos;
			}

			gameTime = 0.0f;
		}

		if (cpTime > 8.0f) {
			Instantiate (Resources.Load("checkPoint"), new Vector3 (0, 1200, 0), Quaternion.identity);
			cpTime = 0.0f;
		}
		if (lifeTime > Random.Range(15.0f,45.0f)) {

			lanePos = (int)lanes [Random.Range (0, 3)];

			if (lanePos != oldlifeX) {
				Instantiate (Resources.Load ("life"), new Vector3 (lanePos, 1200, 0), Quaternion.identity);
				oldlifeX = (int)lanePos;
			} else {
				lanePos = (int)lanes [Random.Range (0, 3)];
				Instantiate (Resources.Load ("life"), new Vector3 (lanePos, 1200, 0), Quaternion.identity);
				oldX = (int)lanePos;
			}

			lifeTime = 0.0f;
		}
	}
}
