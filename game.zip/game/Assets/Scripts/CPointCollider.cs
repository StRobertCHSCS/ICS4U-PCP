﻿using UnityEngine;
using System.Collections;

public class CPointCollider : MonoBehaviour {

	public static int playerScore;


	// Update is called once per frame
	void Update () {

	}

	void OnTriggerEnter(Collider other) {
		if (other.name == "Sphere") {
			if (Time.timeScale < 16.0f) {
				Time.timeScale += 0.15f;
			}
			Score.score += 10;
		} else if (other.tag == "ClearLag") {
			Destroy (gameObject);
		}
	}
}
