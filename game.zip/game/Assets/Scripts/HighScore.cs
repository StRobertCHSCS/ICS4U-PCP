﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class HighScore : MonoBehaviour {

	Text highScoreText;

	public int highscore;

	// Use this for initialization
	void Start () {
		
		highscore = PlayerPrefs.GetInt ("HighScore", 0);
		highScoreText = GetComponent<Text>();
		highScoreText.text = highscore.ToString();
	}
}
