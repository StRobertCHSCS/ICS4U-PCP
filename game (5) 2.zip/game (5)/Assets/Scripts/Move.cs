﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class Move : MonoBehaviour {
	public int lane;
	public static int numlife;


	// Update is called once per frame
	void Start () {
		lane = 0;
		numlife = 1;

	}
	// Update is called once per frame
	void Update () 
	{
		if (Input.GetKeyDown (KeyCode.LeftArrow)) {
			if (lane > -1) 
				lane -= 3;
		}
		if (Input.GetKeyDown (KeyCode.RightArrow)) {
			if (lane < 1) 
				lane += 3;
		}
		Vector3 newPosition = transform.position;
		newPosition.x = lane;
		transform.position = newPosition;




	}

	void OnCollisionEnter(Collision col) {
		Time.timeScale = 1.0f;
		if (col.gameObject.tag == "Cube") {
			if (numlife == 1) {
				SceneManager.LoadScene ("LostMenu");
				Destroy (gameObject);
			} else {
				numlife -= 1;
			}
		}
		if (col.gameObject.tag == "Life") {
			if (numlife < 3) {
				numlife += 1;
			} else {
				Score.score += 10;
			}
		}
		Destroy (col.gameObject);
		
		
				
	}

}
